import React from 'react'

export default function AboutToCarusela(){
    return(
        <>
        <h1>אודות היוצרים של האתר</h1>


        </>
    )
}