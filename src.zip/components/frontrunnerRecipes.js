import React from 'react'

export default function FrontrunnerRecipes(){
    return(
        <>
        <h1>המתכונים המובילים באתר</h1>
        </>
    )
}